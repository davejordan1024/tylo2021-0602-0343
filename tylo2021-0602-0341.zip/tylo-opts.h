// master list of options. len member is the length of the option name, to be filled in by code. type is either (i)nt or (s)tring i.e. char*
// Capital I option is a 24-bit color number and needs to be shifted into the high 3 bytes of an int to fit into fltk's color representation scheme.
// string options have no default since at least one of them will be of indeterminate length and will need heap space for its value.

#define OPTFILE   "tylo-opts.txt"

struct opt_s { string nm; char type, write; int ival; string sval, desc; };

vector <opt_s> opts {

   //             type w   ival        sval     desc
   //           --------------------------------------------------------------
   { "appx",      'i', 1,  500,           "", "app x coordinate at startup"         },
   { "appy",      'i', 1,  100,           "", "app y coordinate at startup"         },
   { "app_bg",    'i', 0,  FL_BLACK,      "", "app background color"                },

   { "msg_bg",    'i', 0,  FL_BLACK,      "", "message area background color"       },
   { "msg_fg",    'i', 0,  FL_WHITE,      "", "message font color"                  },
   { "msg_fs",    'i', 0,  14,            "", "message font size"                   },

   { "list_bg",   'i', 0,  FL_BLACK,      "", "game list background color"          },
   { "list_fg",   'i', 0,  FL_WHITE,      "", "game list font color"                },
   { "list_fs",   'i', 0,  14,            "", "game list font size"                 },    
   { "lw_opp",    'i', 0,  150,           "", "opponent column width in pixels"     },
   { "lw_time",   'i', 0,  80,            "", "timestamp column width in pixels"    },

   { "cellpix",   'i', 0,  24,            "", "board/rack cell size in pixels"      },
   { "cell_bg",   'I', 0,  0x2e3436,      "", "board/rack background color"         }, 
   { "cell_fg",   'i', 0,  FL_WHITE,      "", "board/rack font color"               },
   { "cell_fs",   'i', 0,  24,            "", "board/rack font size"                },
   { "cell_hi",   'i', 0,  FL_DARK_YELLOW,"", "board/rack current cell color"       },
   
   { "clr_tw",    'I', 0,  0xF07162,      "", "triple word color"                   },
   { "clr_dw",    'I', 0,  0xEA201B,      "", "double word color"                   },
   { "clr_tl",    'I', 0,  0xA8C269,      "", "tiple letter color"                  },
   { "clr_dl",    'I', 0,  0x53A3D4,      "", "double letter color"                 },
   { "clr_nm",    'I', 0,  0x2e3436,      "", "no-multiplier color"                 },

   { "stat_bg",   'i', 0,  FL_BLACK,      "", "status line background color"        },
   { "stat_fs",   'i', 0,  14,            "", "status line font size"               },
   { "stat_fg",   'i', 0,  FL_WHITE,      "", "status line font color"              },

   { "notes_bg",  'i', 0,  FL_BLACK,      "", "notes area background color"         },
   { "notes_fs",  'i', 0,  18,            "", "notes font size"                     },
   { "notes_fg",  'i', 0,  FL_WHITE,      "", "notes font color"                    },
   { "notes_cu",  'i', 0,  FL_WHITE,      "", "notes cursor color"                  },

   { "bag_bg",    'i', 0,  FL_BLACK,      "", "bag area background color"           },
   { "bag_posi",  'i', 0,  FL_WHITE,      "", "bag letter: some remaining"          },
   { "bag_zero",  'I', 0,  0x2e3436,      "", "bag letter: none remaining"          },
   { "bag_nega",  'i', 0,  FL_RED,        "", "bag letter: < 0 remaining"           },
   
   { "pad",       'i', 0,  8,             "", "pixels separating app components"    },
   { "find_hi",   'i', 0,  FL_RED,        "", "found letter font color"             },
   { "autoright", 'i', 0,  true,          "", "rack: auto advance to next cell"     },
   { "tbl_bg",    'i', 0,  FL_BLACK,      "", "color for game-specific widget area" },
   { "lastgame",  's', 1,  0,             "", "last game shown before exit"         },
   { "lastsort",  's', 1,  0,             "4","game list order at startup"          }     // default: 4th function in array of function ptrs in sort_brwsr()
   
};
const int nopts = opts.size();

int srch_opts(string nm) {

   int top = 0, mid, cmp, btm = nopts - 1;
   
   while(top <= btm) {
      mid = top + (btm - top) / 2;
      cmp = opts[mid].nm.compare(nm);
      if       (cmp < 0) top = mid + 1;
      else if  (cmp > 0) btm = mid - 1;
      else     return mid;
   }
   return -1;
}
int getiopt(string nm) {
   
   int idx = srch_opts(nm);
   if(idx < 0)                EOPT(nm, "is unknown");
   if(opts[idx].type == 's')  EOPT(nm, "is the wrong type");
   return opts[idx].ival;
}
string getsopt(string nm) {

   int idx = srch_opts(nm);   
   if(idx < 0)                EOPT(nm, "is unknown");
   if(opts[idx].type != 's')  EOPT(nm, "is the wrong type");
   return opts[idx].sval;
}
void read_opts() {

   int j, longlen = 0;
   
   for(j = 0; j < nopts; j++) {                                   // vector <opt_s> opts - housekeeping
      if(opts[j].nm.length() > longlen)                           // length of longest opt name
         longlen = opts[j].nm.length();
      if(opts[j].type == 'I')                                     // left shift mostly for colors not specified as FL_*
         opts[j].ival <<= 8;                                      // (optfile doesn't use FL_* as constants)
   }
   
   sort(std::begin(opts), std::end(opts), [] (const opt_s &opt1, const opt_s &opt2) { return opt1.nm.compare(opt2.nm) < 0; });

   FILE        *ifh;
   char        *line    = NULL,
               regex1[] = "^[ \t=]+([^#]+)", // the combined effect of the two regexecs is to isolate from line a string option val
               regex2[] = "([ \t]*)$",       // which may be preceded by [ \t=]+ and followed by any amount of blanks and/or a #-delimited comment.
               nm[longlen + 1],              // i do not believe POSIX r.e.'s can do this in one step. (Perl r.e.'s can).
               *sval;
   bool        match;
   size_t      n = 0;
   regex_t     preg1, preg2;
   regmatch_t  pmatch[2];

   cout << "read " OPTFILE << endl;

   #define RCFLAGS (REG_ICASE | REG_EXTENDED | REG_NEWLINE) // NEWLINE flag very important to avoid getsopt returning optionvalue\n
   if(regcomp(&preg1, regex1, RCFLAGS))   EINIT("internal error: recomp #1 failed");
   if(regcomp(&preg2, regex2, RCFLAGS))   EINIT("internal error: recomp #2 failed");

   if(! (ifh = fopen(OPTFILE, "r"))) {  }
   

   while(getline(&line, &n, ifh) != -1) {                   // self-allocates, is nul terminated, and includes the newline character, if one was found.
      if(line[0] == '\0')                                   // do not try to process blank lines
         continue;
      match = false;                                        // can't use srch_opts b/c i am comparing line against every opt until match or max element
      for(j = 0; j < nopts; j++) {
         if(! ((string) line).compare(0, opts[j].nm.length(), opts[j].nm)) {
            match = true;
            break;                                          // found match
         }
      }

      if(! match)
         continue;                                          // next getline
      switch(opts[j].type) {
         // need logic for integer opt name with no value
         case 'i' :  opts[j].ival = strtoul(line + opts[j].nm.length(), NULL, 0);      // using strtoul so opts can start with 0x if desired.
                     opts[j].write = 1;
                     continue;                                                         // next getline
         case 'I' :  opts[j].ival = strtoul(line + opts[j].nm.length(), NULL, 0) << 8; // shift a non FL_* color into fltk's color scheme
                     opts[j].write = 1;
                     continue;                                                         // next getline
         case 's' :  break;                                                            // string value - break to remainder of func
         default  :  fl_alert("internal error: unknown type for %s", opts[j].nm.c_str());
      }
      sval = &line[opts[j].nm.length()];                    // sval points to char after option name
      if(regexec(&preg1, sval, 2, pmatch, 0))
         continue;                                          // no match
      if(pmatch[1].rm_so == -1)
         continue;                                          // no match to capture group: i.e. optname=\0
      sval += pmatch[1].rm_so;                              // trim delimiting prefix from val
      sval[pmatch[1].rm_eo - 1] = '\0';                     // trim comment suffix

      if(regexec(&preg2, sval, 2, pmatch, 0))
         EINIT("internal error: regexec #2 failed");
      try {
         opts[j].sval.assign(sval, pmatch[1].rm_so);
      }
      catch(...) {
         EOOM ("option string value");
      }
      opts[j].write = 1;
   }
   fclose(ifh); free(line); regfree(&preg1); regfree(&preg2);
}
void write_opts(App *app) {

   cout << "write opts" << endl;
   
   bool wrote;

   fstream optfs(OPTFILE, fstream::in | fstream::out | fstream::trunc);    // fails if trunc is set but out is not. sensible.
   
   if(! optfs)
      fl_alert("Failed to open %s, could not save options.", OPTFILE);
   else {
      for(int j = 0; j < nopts; j++) {
         wrote = true;
         if       (! opts[j].nm.compare("appx"))
            optfs << "appx\t" << app->x();
         else if  (! opts[j].nm.compare("appy"))
            optfs << "appy\t" << app->y();
         else if  (! opts[j].nm.compare("lastgame"))
            optfs << "lastgame\t" << cur.game->opp << '|' << cur.game->starttm;
         else if  (! opts[j].nm.compare("lastsort"))
            optfs << "lastsort\t" << app->brwsr->lastsort;

         else if(opts[j].write) {
            switch(opts[j].type) {
               case 's':   optfs << opts[j].nm << '\t' << opts[j].sval;
               break;
               case 'i':   optfs << opts[j].nm << '\t' << opts[j].ival;
               break;
               case 'I':   optfs << opts[j].nm << '\t' << (opts[j].ival >> 8);
               break;
               default:    wrote = false;    // need in case write == 1 and type unknown
            }
         }
         else
            wrote = false;
         if(wrote)
            optfs << '\n';
      }
      optfs.close();
   }
}
